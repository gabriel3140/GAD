<?php
session_start();

// Initializing variables with empty values
$first_name = "";
$last_name = "";
$username = "";
$email = "";
$password_1 = "";
$password_2 = "";
$mobile = "";
$errors = array(
    'username' => '',
    'first_name' => '',
    'last_name' => '',
    'email' => '',
    'password_1' => '',
    'password_2' => '',
    'mobile' => '',
    'general' => ''
);

// Connect to the database using PDO
try {
    $db = new PDO('mysql:host=localhost;dbname=inventorymanagement;charset=utf8', 'root', '');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Failed to connect to MySQL: " . $e->getMessage();
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
    // CHECK QUANTITY
if (isset($_POST['action']) && $_POST['action'] === 'checkQuantity') {
    header('Content-Type: application/json');

    $productId = $_POST['productId'];

    $stmt = $db->prepare("SELECT quantity FROM product WHERE product_id = :productId");
    $stmt->execute([':productId' => $productId]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product) {
        $availableQuantity = $product['quantity'];
        echo json_encode(['success' => true, 'quantity' => $availableQuantity]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Product not found']);
    }
    exit();
}
    // REGISTER USER
    if (isset($_POST['reg_user'])) {
        // Receive all input values from the form
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password_1 = $_POST['password_1'];
        $password_2 = $_POST['password_2'];
        $mobile = $_POST['mobile'];
        $user_type = isset($_POST['user_type']) ? $_POST['user_type'] : 'user'; // Default to 'user' if not specified

        // Form validation: ensure that the form is correctly filled
        if (empty($username)) { $errors['username'] = "Username is required"; }
        if (empty($first_name)) { $errors['first_name'] = "First Name is required"; }
        if (empty($last_name)) { $errors['last_name'] = "Last Name is required"; }
        if (empty($email)) { $errors['email'] = "Email is required"; }
        if (empty($password_1)) { $errors['password_1'] = "Password is required"; }
        if (empty($mobile)) { $errors['mobile'] = "Mobile is required"; }
        if ($password_1 != $password_2) {
            $errors['password_2'] = "The two passwords do not match";
        }

        // First check the database to make sure a user does not already exist with the same username and/or email
        $stmt = $db->prepare("SELECT * FROM register WHERE username = :username OR email = :email LIMIT 1");
        $stmt->execute([':username' => $username, ':email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) { // if user exists
            if ($user['username'] === $username) {
                $errors['username'] = "Username already exists";
            }
            if ($user['email'] === $email) {
                $errors['email'] = "Email already exists";
            }
        }

        // Only set the Content-Type to JSON for JSON responses
        if (!empty(array_filter($errors))) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'errors' => $errors]);
            exit();
        }

        // Finally, register the user if there are no errors in the form
        if (empty(array_filter($errors))) {
            $password = password_hash($password_1, PASSWORD_BCRYPT); // Encrypt the password before saving in the database
            $stmt = $db->prepare("INSERT INTO register (username, first_name, last_name, email, password, mobile, user_type) VALUES (:username, :first_name, :last_name, :email, :password, :mobile, :user_type)");
            $stmt->execute([
                ':username' => $username,
                ':first_name' => $first_name,
                ':last_name' => $last_name,
                ':email' => $email,
                ':password' => $password,
                ':mobile' => $mobile,
                ':user_type' => $user_type
            ]);

            $_SESSION['username'] = $username;
            $_SESSION['success'] = "You are now logged in";

          
                header('location: login.php');
            

            exit(); // Ensure to exit after redirection
        }
    }

    // LOGIN USER
    if (isset($_POST['login_user'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if (empty($username)) {
            $errors['username'] = "Username is required";
        }
        if (empty($password)) {
            $errors['password_1'] = "Password is required";
        }

        if (!empty(array_filter($errors))) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'errors' => $errors]);
            exit();
        }

        if (empty(array_filter($errors))) {
            $stmt = $db->prepare("SELECT * FROM register WHERE username = :username");
            $stmt->execute([':username' => $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['username'] = $username;
                $_SESSION['user_type'] = $user['user_type']; // Store user type in session
                $_SESSION['success'] = "You are now logged in";

                if ($user['user_type'] === 'admin') {
                    header('location: index1.php');
                } else {
                    header('location: index2.php');
                }
                exit(); // Ensure to exit after redirection
            } else {
                $errors['general'] = "Wrong username/password combination";
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'errors' => $errors]);
                exit();
            }
        }
    }

    // CHECKOUT
    if (isset($_POST['checkout'])) {
        header('Content-Type: application/json');

        $customerName = $_POST['customerName'];
        $customerEmail = $_POST['customerEmail'];
        $cart = json_decode($_POST['cart'], true);

        // Start transaction
        $db->beginTransaction();

        try {
            // Insert transaction into database
            $stmt = $db->prepare("INSERT INTO transactions (customer_name, customer_email, total_price, created_at) VALUES (:customerName, :customerEmail, 0, NOW())");
            $stmt->execute([':customerName' => $customerName, ':customerEmail' => $customerEmail]);
            $transactionId = $db->lastInsertId();
            $totalPrice = 0;

            foreach ($cart as $item) {
                $product = $item['product'];
                $quantity = (int)$item['quantity'];
                $price = (float)$item['price'];
                $total = (float)$item['total'];

                // Insert each cart item into transaction_items table
                $stmt = $db->prepare("INSERT INTO transaction_items (transaction_id, product_name, quantity, price, total) VALUES (:transactionId, :product, :quantity, :price, :total)");
                $stmt->execute([
                    ':transactionId' => $transactionId,
                    ':product' => $product,
                    ':quantity' => $quantity,
                    ':price' => $price,
                    ':total' => $total
                ]);

                // Update total price for the transaction
                $totalPrice += $total;

                // Update product quantity in the "product" table
                $stmt = $db->prepare("UPDATE product SET quantity = quantity - :quantity WHERE product_name = :product");
                $stmt->execute([':quantity' => $quantity, ':product' => $product]);
            }

            // Update total price in transactions table
            $stmt = $db->prepare("UPDATE transactions SET total_price = :totalPrice WHERE id = :transactionId");
            $stmt->execute([':totalPrice' => $totalPrice, ':transactionId' => $transactionId]);

            // Commit transaction
            $db->commit();
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            // Rollback transaction
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => 'Transaction failed: ' . $e->getMessage()]);
        }
        exit();
    }

    // CHECK PRODUCT QUANTITY
    if (isset($_POST['checkQuantity'])) {
        header('Content-Type: application/json');

        $productId = $_POST['productId'];

        try {
            $stmt = $db->prepare("SELECT quantity FROM product WHERE product_id = :productId");
            $stmt->execute([':productId' => $productId]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($product) {
                echo json_encode(['quantity' => $product['quantity']]);
            } else {
                echo json_encode(['quantity' => 0]);
            }
        } catch (Exception $e) {
            echo json_encode(['quantity' => 0, 'message' => 'Error checking quantity: ' . $e->getMessage()]);
        }
        exit();
    }

       // CHECK SALES
if (isset($_POST['check_sales'])) {
    header('Content-Type: application/json');

    $startDate = $_POST['startDate'];
    $endDate = $_POST['endDate'];

    try {
        // Fetch sales data between the specified dates
        $stmt = $db->prepare("SELECT * FROM sales WHERE created_at BETWEEN :startDate AND :endDate");
        $stmt->execute([':startDate' => $startDate, ':endDate' => $endDate]);
        $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Prepare response
        $response = [
            'success' => true,
            'sales' => $sales
        ];

        // Send JSON response
        echo json_encode($response);
        exit();
    } catch (PDOException $e) {
        // Handle database errors
        echo json_encode(['success' => false, 'message' => 'Error fetching sales: ' . $e->getMessage()]);
        exit();
    }
}
    // CHECK QUANTITY
if (isset($_POST['action']) && $_POST['action'] === 'checkQuantity') {
    header('Content-Type: application/json');

    $productId = $_POST['productId'];

    $stmt = $db->prepare("SELECT quantity FROM product WHERE product_id = :productId");
    $stmt->execute([':productId' => $productId]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product) {
        $availableQuantity = $product['quantity'];
        echo json_encode(['success' => true, 'quantity' => $availableQuantity]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Product not found']);
    }
    exit();
}
}

// Display errors (if any) for normal HTML responses
foreach ($errors as $error) {
    if (!empty($error)) {
        echo $error . "<br>";
    }
}
?>
